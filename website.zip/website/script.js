function spawn(){
  window.location.href = "/add.html"
}


function box() {
  //lets
  let totaldiv = document.createElement("div");
  let descript = document.createElement("input");
  let title = document.createElement("input");
  let clear = document.createElement("button");
  //totaldiv stuff
  totaldiv.style.textAlign = "center"
  totaldiv.style.borderColor ="green"
  totaldiv.style.borderWidth = "10"
  totaldiv.style.borderStyle = "solid"
  totaldiv.id = "div"
  //title stuff
  title.style.display = "block"
  title.style.margin = "10px auto"
  title.style.borderWidth = "5px"
  title.style.padding = "5px"
  title.type = "text"
  title.placeholder = "Enter title here..."
  title.id = "title"
  //descript stuff
  descript.type = "text"
  descript.placeholder = "Enter description here..."
  descript.style.textAlign = "center"
  descript.style.display = "block"
  descript.style.margin = "10px auto"
  descript.style.borderWidth = "5px"
  descript.style.padding = "5px"
  descript.id = "des"
  //button stuff
  clear.style.backgroundColor = "blue"
  clear.onclick = spawn;
  clear.innerHTML = "Continue"
  clear.style.fontSize = "10px"
  clear.style.height = "25px"
  clear.style.width = "50px"
  clear.id = "button"
  // appending
  document.body.appendChild(totaldiv);
  totaldiv.appendChild(title)
  totaldiv.appendChild(descript)
  totaldiv.appendChild(clear)
  
}

function create() {
  box()
  document.getElementById("button1").remove();
  document.getElementById("button2").remove();
}


function test() {
  window.location.href = "/add.html"

}



function display2(){
let trackers =  JSON.parse(localStorage.getItem("trackers")) || []
trackers.forEach(tracker => {
  let title = document.createElement("p")
  let description = document.createElement("p")
  title.innerHTML = tracker.title
  description.innerHTML = tracker.description
  document.body.appendChild(title)
  document.body.appendChild(description)
})
}

window.onload = display2;